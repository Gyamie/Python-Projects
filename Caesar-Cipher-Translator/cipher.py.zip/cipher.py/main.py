import art

alphabet = [
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o',
    'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'a', 'b', 'c', 'd',
    'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's',
    't', 'u', 'v', 'w', 'x', 'y', 'z'
]
print(art.logo)


def caesar(letters, Number_of_shift, cipher_direction):
    # def encrypt (letters,Number_of_shift):
    cipher_text = ''
    if cipher_direction == 'decode':
        #this would negate the shift number eg 3*-1 = -3
        Number_of_shift *= -1
    for letter in letters:
        if letter in alphabet:
            Position = alphabet.index(letter)
            letter_update = Position + Number_of_shift
            cipher_text += alphabet[letter_update]
        else:
            cipher_text += letter
    print(f'the {cipher_direction}d text is {cipher_text}')



while True:
    
        direction = input("Type 'encode' to encrypt, type 'decode' to decrypt:\n")
        text = input("Type your message:\n").lower()
        shift = int(input("Type the shift number:\n"))
        shift = shift % 26
        caesar(text, shift, direction)
        Go_again = input('Do you want to try again? yes or no\n').lower()
        if Go_again == 'no':
          print('goodbye')
          break
